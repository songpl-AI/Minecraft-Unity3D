#!/usr/bin/env python3
"""
Build script to package the video-analyzer skill into a .skill file
"""

import os
import zipfile
import shutil
from pathlib import Path


def build_skill():
    """Build the video-analyzer skill package"""

    # Paths
    skill_name = "video-analyzer"
    skill_dir = Path(skill_name)
    output_file = f"{skill_name}.skill"

    # Files to exclude
    exclude_patterns = ["__pycache__", "*.pyc", ".git", "*.skill", "SKILL_SUMMARY.md"]

    # Check if skill directory exists
    if not skill_dir.exists():
        print(f"❌ Error: {skill_name} directory not found")
        return

    # Remove existing .skill file if it exists
    if os.path.exists(output_file):
        os.remove(output_file)
        print(f"Removed existing {output_file}")

    # Create zip archive
    print(f"Building {output_file}...")

    with zipfile.ZipFile(output_file, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(skill_dir):
            # Remove excluded directories
            dirs[:] = [
                d for d in dirs if not any(pattern in d for pattern in exclude_patterns)
            ]

            for file in files:
                # Check if file should be excluded
                file_path = Path(root) / file
                if any(
                    file.endswith(pattern.replace("*", ""))
                    for pattern in exclude_patterns
                    if pattern.startswith("*")
                ) or file in ["SKILL_SUMMARY.md"]:
                    continue

                arcname = f"{skill_name}/{file_path.relative_to(skill_dir)}"

                print(f"  Adding: {arcname}")
                zipf.write(file_path, arcname)

    # Get file size
    file_size = os.path.getsize(output_file) / 1024  # KB
    print(f"\n✅ Successfully built {output_file}")
    print(f"   Size: {file_size:.1f} KB")

    # List contents
    print(f"\nContents:")
    with zipfile.ZipFile(output_file, "r") as zipf:
        for info in zipf.filelist:
            print(f"  - {info.filename} ({info.file_size} bytes)")


if __name__ == "__main__":
    build_skill()
