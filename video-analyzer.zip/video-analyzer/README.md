# Video Analyzer Skill

Automated video quality analysis tool that detects common video issues including black screen frames, missing audio tracks, and subtitle absence.

## Features

- **Black Screen Detection**: Identifies frames that are predominantly black or dark
- **Audio Verification**: Checks for presence and characteristics of audio tracks
- **Subtitle Detection**: Identifies embedded and external subtitle files
- **Multiple Output Formats**: JSON, Markdown reports, and console output
- **Remote Video Support**: Analyze videos from URLs with automatic downloading
- **Batch Processing**: Analyze multiple videos efficiently
- **Configurable Thresholds**: Customize detection sensitivity

## Requirements

### System Dependencies

```bash
# macOS
brew install ffmpeg

# Linux (Ubuntu/Debian)
sudo apt-get install ffmpeg
```

### Python Packages

```bash
pip install opencv-python numpy ffmpeg-python
```

## Quick Start

### Basic Usage

```python
from scripts.video_analyzer import VideoAnalyzer

# Analyze a video file
analyzer = VideoAnalyzer('video.mp4')
results = analyzer.analyze()

# Print report
print(results.get_report())
```

### Check for Issues

```python
analyzer = VideoAnalyzer('video.mp4')
results = analyzer.analyze()

if results.has_issues():
    print(f"Found {results.issue_count} issues:")
    for issue in results.get_issues():
        print(f"  - {issue}")
else:
    print("✅ No issues detected")
```

### Export Results

```python
# Export to JSON
results.to_json('results.json')

# Export to Markdown report
results.to_report_file('report.md')
```

## Command Line Usage

```bash
# Analyze video with default settings
python scripts/video_analyzer.py video.mp4

# Save results to file
python scripts/video_analyzer.py video.mp4 --output results.json

# Generate markdown report
python scripts/video_analyzer.py video.mp4 --output report.md

# Custom black screen threshold
python scripts/video_analyzer.py video.mp4 --black-threshold 15

# Sample every 10th frame (faster analysis)
python scripts/video_analyzer.py video.mp4 --sample-rate 10

# Enable verbose logging
python scripts/video_analyzer.py video.mp4 --verbose
```

## Advanced Examples

### Analyze Remote Video

```python
analyzer = VideoAnalyzer('https://example.com/video.mp4')
results = analyzer.analyze()
print(results.get_report())
```

### Custom Thresholds

```python
analyzer = VideoAnalyzer(
    'video.mp4',
    black_threshold=20,    # Higher threshold (more lenient)
    sample_rate=5          # Sample every 5th frame
)
results = analyzer.analyze()
```

### Specific Timestamps

```python
# Analyze only at specific timestamps
analyzer = VideoAnalyzer('video.mp4')
results = analyzer.analyze(timestamps=[0.0, 30.0, 60.0, 90.0])
```

### Batch Processing

```python
from pathlib import Path

for video_path in Path('videos/').glob('*.mp4'):
    print(f"\nAnalyzing: {video_path.name}")
    analyzer = VideoAnalyzer(str(video_path))
    results = analyzer.analyze()

    if results.has_issues():
        print(f"  Issues: {results.issue_count}")
    else:
        print("  ✅ No issues")
```

## Output Formats

### JSON

```json
{
  "video_path": "video.mp4",
  "duration": 120.5,
  "resolution": "1920x1080",
  "black_screen": {
    "detected": true,
    "percentage": 2.5,
    "timestamps": [10.2, 10.4, 10.6]
  },
  "audio": {
    "has_audio": true,
    "codec": "aac",
    "sample_rate": 48000
  },
  "subtitles": {
    "has_subtitles": true,
    "tracks": [
      {
        "language": "eng",
        "format": "srt",
        "embedded": true
      }
    ]
  }
}
```

### Markdown Report

```markdown
# Video Analysis Report: video.mp4

## Video Information
- **Duration**: 120.5s
- **Resolution**: 1920x1080

## Black Screen Detection
- **Status**: ⚠️  Issue Found
- **Black Frames**: 2.5% (3 frames)

## Audio Detection
- **Status**: ✅ Passed
- **Codec**: AAC

## Subtitle Detection
- **Status**: ✅ Passed
- **Tracks**: 1 found
  - English (SRT, embedded)
```

## API Reference

### VideoAnalyzer Class

```python
VideoAnalyzer(
    video_path: str,
    black_threshold: int = 10,
    audio_threshold: float = 0.01,
    sample_rate: int = 1,
    download_dir: str = './downloads',
    timeout: int = 300
)
```

**Parameters:**
- `video_path`: Path or URL to video file
- `black_threshold`: Brightness threshold for black detection (0-255)
- `audio_threshold`: Volume threshold for silence detection
- `sample_rate`: Frame sampling rate (every Nth frame)
- `download_dir`: Directory for downloaded videos
- `timeout`: Download timeout in seconds

**Methods:**
- `analyze(timestamps=None)`: Perform complete analysis
- `analyze_black_screen(timestamps=None)`: Detect black frames
- `analyze_audio()`: Check for audio
- `analyze_subtitles()`: Check for subtitles
- `ffmpeg_available()`: Check if FFmpeg is installed

### VideoAnalysisResult Class

**Properties:**
- `has_issues()`: Check if any issues detected
- `issue_count`: Number of issues found
- `has_black_frames()`: Check for black frames
- `black_frame_percentage`: Percentage of black frames
- `black_frame_timestamps`: List of black frame timestamps
- `has_audio()`: Check if audio is present
- `has_subtitles()`: Check if subtitles are present

**Methods:**
- `to_dict()`: Convert to dictionary
- `to_json()`: Convert to JSON string
- `get_report()`: Generate markdown report
- `to_file(filepath)`: Save JSON to file
- `to_report_file(filepath)`: Save report to markdown file

## Building the Skill

To package the skill into a `.skill` file:

```bash
python build.py
```

This creates `video-analyzer.skill` which can be imported into OpenCode.

## Examples

See `example.py` for comprehensive usage examples:

```bash
python example.py
```

## Limitations

1. **OCR Subtitle Detection**: Currently only detects embedded subtitle tracks. Burned-in subtitles require OCR integration.

2. **Audio Content Analysis**: Detects presence of audio but cannot verify audio quality or content accuracy.

3. **Color Grading**: Black screen detection based on brightness may flag intentionally dark scenes.

4. **Network Videos**: Remote video analysis requires stable internet connection.

## Troubleshooting

### FFmpeg not found

```
Error: FFmpeg is not installed
```

**Solution**: Install FFmpeg:
- macOS: `brew install ffmpeg`
- Linux: `sudo apt-get install ffmpeg`

### Missing dependencies

```
ModuleNotFoundError: No module named 'cv2'
```

**Solution**: Install required packages:
```bash
pip install opencv-python numpy ffmpeg-python
```

### Video file not found

```
FileNotFoundError: Video file not found: video.mp4
```

**Solution**: Verify the video file path is correct and the file exists.

### High black frame percentage

If black screen detection reports many black frames, try:
- Increase `black_threshold` (e.g., 15-20)
- Check if dark scenes are intentional (night scenes, fade effects)

## License

MIT
