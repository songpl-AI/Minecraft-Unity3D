#!/usr/bin/env python3
"""
Video Analyzer - Comprehensive video quality analysis tool
Detects black screen frames, missing audio, and subtitle absence
"""

import os
import json
import logging
import urllib.request
import subprocess
import tempfile
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

try:
    import cv2
    import numpy as np
except ImportError:
    print(
        "Required dependencies not found. Install with: pip install opencv-python numpy"
    )
    raise

try:
    import ffmpeg
except ImportError:
    print("FFmpeg Python binding not found. Install with: pip install ffmpeg-python")
    raise


class IssueType(Enum):
    """Types of video issues that can be detected"""

    BLACK_FRAMES = "black_frames"
    NO_AUDIO = "no_audio"
    NO_SUBTITLES = "no_subtitles"


@dataclass
class AudioInfo:
    """Audio track information"""

    has_audio: bool
    codec: Optional[str] = None
    sample_rate: Optional[int] = None
    duration: Optional[float] = None
    silent_sections: List[Tuple[float, float]] = field(default_factory=list)
    error: Optional[str] = None


@dataclass
class BlackScreenInfo:
    """Black screen detection results"""

    detected: bool
    percentage: float
    timestamps: List[float] = field(default_factory=list)
    threshold: int = 10


@dataclass
class SubtitleTrack:
    """Individual subtitle track information"""

    language: str
    format: str
    embedded: bool


@dataclass
class SubtitleInfo:
    """Subtitle detection results"""

    has_subtitles: bool
    tracks: List[SubtitleTrack] = field(default_factory=list)
    error: Optional[str] = None


@dataclass
class VideoAnalysisResult:
    """Complete video analysis results"""

    video_path: str
    duration: Optional[float] = None
    resolution: Optional[str] = None
    fps: Optional[float] = None
    black_screen: Optional[BlackScreenInfo] = None
    audio: Optional[AudioInfo] = None
    subtitles: Optional[SubtitleInfo] = None
    _issues: List[IssueType] = field(default_factory=list)

    def has_issues(self) -> bool:
        """Check if any issues were detected"""
        return len(self._issues) > 0

    @property
    def issue_count(self) -> int:
        """Get total number of issues"""
        return len(self._issues)

    def has_black_frames(self) -> bool:
        """Check if black frames were detected"""
        return self.black_screen is not None and self.black_screen.detected

    @property
    def black_frame_percentage(self) -> float:
        """Get percentage of black frames"""
        return self.black_screen.percentage if self.black_screen else 0.0

    @property
    def black_frame_timestamps(self) -> List[float]:
        """Get timestamps of black frames"""
        return self.black_screen.timestamps if self.black_screen else []

    def has_audio(self) -> bool:
        """Check if audio is present"""
        return self.audio is not None and self.audio.has_audio

    def has_subtitles(self) -> bool:
        """Check if subtitles are present"""
        return self.subtitles is not None and self.subtitles.has_subtitles

    def add_issue(self, issue_type: IssueType):
        """Add an issue to the results"""
        if issue_type not in self._issues:
            self._issues.append(issue_type)

    def get_issues(self) -> List[str]:
        """Get list of issue descriptions"""
        issues_map = {
            IssueType.BLACK_FRAMES: f"Black frames detected ({self.black_frame_percentage:.1f}%)",
            IssueType.NO_AUDIO: "No audio detected",
            IssueType.NO_SUBTITLES: "No subtitles detected",
        }
        return [issues_map[issue] for issue in self._issues]

    def to_dict(self) -> Dict:
        """Convert results to dictionary"""
        result = {
            "video_path": self.video_path,
            "duration": self.duration,
            "resolution": self.resolution,
            "fps": self.fps,
            "has_issues": self.has_issues(),
            "issue_count": self.issue_count,
        }

        if self.black_screen:
            result["black_screen"] = {
                "detected": self.black_screen.detected,
                "percentage": self.black_screen.percentage,
                "timestamps": self.black_screen.timestamps,
            }

        if self.audio:
            result["audio"] = {
                "has_audio": self.audio.has_audio,
                "codec": self.audio.codec,
                "sample_rate": self.audio.sample_rate,
                "duration": self.audio.duration,
                "silent_sections": self.audio.silent_sections,
            }
            if self.audio.error:
                result["audio"]["error"] = self.audio.error

        if self.subtitles:
            result["subtitles"] = {
                "has_subtitles": self.subtitles.has_subtitles,
                "tracks": [
                    {
                        "language": track.language,
                        "format": track.format,
                        "embedded": track.embedded,
                    }
                    for track in self.subtitles.tracks
                ],
            }
            if self.subtitles.error:
                result["subtitles"]["error"] = self.subtitles.error

        return result

    def to_json(self, indent: int = 2) -> str:
        """Convert results to JSON string"""
        return json.dumps(self.to_dict(), indent=indent)

    def get_report(self) -> str:
        """Generate markdown report"""
        lines = [f"# Video Analysis Report: {Path(self.video_path).name}\n"]

        # Video information
        lines.append("## Video Information")
        if self.duration:
            lines.append(f"- **Duration**: {self.duration:.1f}s")
        if self.resolution:
            lines.append(f"- **Resolution**: {self.resolution}")
        if self.fps:
            lines.append(f"- **FPS**: {self.fps:.1f}")
        lines.append("")

        # Black screen detection
        lines.append("## Black Screen Detection")
        if self.black_screen:
            if self.black_screen.detected:
                lines.append(f"- **Status**: ⚠️  Issue Found")
                lines.append(
                    f"- **Black Frames**: {self.black_screen.percentage:.1f}% ({len(self.black_screen.timestamps)} frames)"
                )
                if self.black_screen.timestamps:
                    ts_str = ", ".join(
                        f"{t:.1f}s" for t in self.black_screen.timestamps[:5]
                    )
                    if len(self.black_screen.timestamps) > 5:
                        ts_str += (
                            f" ... (+{len(self.black_screen.timestamps) - 5} more)"
                        )
                    lines.append(f"- **Timestamps**: {ts_str}")
            else:
                lines.append("- **Status**: ✅ Passed")
        else:
            lines.append("- **Status**: Not analyzed")
        lines.append("")

        # Audio detection
        lines.append("## Audio Detection")
        if self.audio:
            if self.audio.has_audio:
                lines.append("- **Status**: ✅ Passed")
                if self.audio.codec:
                    lines.append(f"- **Codec**: {self.audio.codec.upper()}")
                if self.audio.sample_rate:
                    lines.append(f"- **Sample Rate**: {self.audio.sample_rate} Hz")
                if self.audio.duration:
                    lines.append(f"- **Duration**: {self.audio.duration:.1f}s")
            else:
                lines.append("- **Status**: ❌ Failed")
                lines.append("- **Issue**: No audio detected")
            if self.audio.error:
                lines.append(f"- **Error**: {self.audio.error}")
        else:
            lines.append("- **Status**: Not analyzed")
        lines.append("")

        # Subtitle detection
        lines.append("## Subtitle Detection")
        if self.subtitles:
            if self.subtitles.has_subtitles:
                lines.append("- **Status**: ✅ Passed")
                lines.append(f"- **Tracks**: {len(self.subtitles.tracks)} found")
                for track in self.subtitles.tracks:
                    embed_str = "(embedded)" if track.embedded else "(external)"
                    lines.append(f"  - {track.language} ({track.format}, {embed_str})")
            else:
                lines.append("- **Status**: ❌ Failed")
                lines.append("- **Issue**: No subtitles detected")
            if self.subtitles.error:
                lines.append(f"- **Error**: {self.subtitles.error}")
        else:
            lines.append("- **Status**: Not analyzed")
        lines.append("")

        # Overall status
        lines.append("## Overall Status")
        if self.has_issues():
            lines.append(f"⚠️  Found {self.issue_count} issue(s):")
            for issue in self.get_issues():
                lines.append(f"  - {issue}")
        else:
            lines.append("✅ No issues detected")

        return "\n".join(lines)

    def to_file(self, filepath: str):
        """Save results to JSON file"""
        with open(filepath, "w") as f:
            f.write(self.to_json())

    def to_report_file(self, filepath: str):
        """Save report to markdown file"""
        with open(filepath, "w") as f:
            f.write(self.get_report())


class VideoAnalyzer:
    """Main video analyzer class"""

    def __init__(
        self,
        video_path: str,
        black_threshold: int = 10,
        audio_threshold: float = 0.01,
        sample_rate: int = 1,
        download_dir: str = "./downloads",
        timeout: int = 300,
    ):
        """
        Initialize video analyzer

        Args:
            video_path: Path or URL to video file
            black_threshold: Brightness threshold for black detection (0-255)
            audio_threshold: Volume threshold for silence detection
            sample_rate: Frame sampling rate (every Nth frame)
            download_dir: Directory for downloaded videos
            timeout: Download timeout in seconds
        """
        self.video_path = video_path
        self.black_threshold = black_threshold
        self.audio_threshold = audio_threshold
        self.sample_rate = sample_rate
        self.download_dir = download_dir
        self.timeout = timeout
        self._local_video_path = None
        self.logger = logging.getLogger(__name__)

        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        )

        # Initialize video path
        self._init_video_path()

    def _init_video_path(self):
        """Initialize video path (download if URL)"""
        if self._is_url(self.video_path):
            self.logger.info(f"Detected remote URL: {self.video_path}")
            self._local_video_path = self._download_video(self.video_path)
        else:
            self._local_video_path = self.video_path

        # Verify file exists
        if not os.path.exists(self._local_video_path):
            raise FileNotFoundError(f"Video file not found: {self._local_video_path}")

    def _is_url(self, path: str) -> bool:
        """Check if path is a URL"""
        return path.startswith(("http://", "https://"))

    def _download_video(self, url: str) -> str:
        """Download video from URL"""
        os.makedirs(self.download_dir, exist_ok=True)

        filename = os.path.basename(url)
        if not filename or "." not in filename:
            filename = f"downloaded_video_{hash(url)}.mp4"

        local_path = os.path.join(self.download_dir, filename)

        self.logger.info(f"Downloading video to: {local_path}")

        try:
            urllib.request.urlretrieve(url, local_path)
            self.logger.info(f"Download completed successfully")
            return local_path
        except Exception as e:
            raise RuntimeError(f"Failed to download video: {e}")

    def ffmpeg_available(self) -> bool:
        """Check if FFmpeg is available"""
        try:
            subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def analyze(self, timestamps: Optional[List[float]] = None) -> VideoAnalysisResult:
        """
        Perform complete video analysis

        Args:
            timestamps: Specific timestamps to analyze (optional)

        Returns:
            VideoAnalysisResult with all detection results
        """
        self.logger.info(f"Starting video analysis: {self._local_video_path}")

        result = VideoAnalysisResult(video_path=self.video_path)

        # Get video metadata
        try:
            duration, resolution, fps = self._get_video_metadata()
            result.duration = duration
            result.resolution = resolution
            result.fps = fps
        except Exception as e:
            self.logger.error(f"Failed to get video metadata: {e}")

        # Perform black screen detection
        try:
            result.black_screen = self.analyze_black_screen(timestamps)
            if result.black_screen.detected:
                result.add_issue(IssueType.BLACK_FRAMES)
        except Exception as e:
            self.logger.error(f"Black screen analysis failed: {e}")

        # Perform audio analysis
        try:
            result.audio = self.analyze_audio()
            if not result.audio.has_audio:
                result.add_issue(IssueType.NO_AUDIO)
        except Exception as e:
            self.logger.error(f"Audio analysis failed: {e}")

        # Perform subtitle analysis
        try:
            result.subtitles = self.analyze_subtitles()
            if not result.subtitles.has_subtitles:
                result.add_issue(IssueType.NO_SUBTITLES)
        except Exception as e:
            self.logger.error(f"Subtitle analysis failed: {e}")

        self.logger.info(
            f"Video analysis completed. Issues found: {result.issue_count}"
        )

        return result

    def _get_video_metadata(
        self,
    ) -> Tuple[Optional[float], Optional[str], Optional[float]]:
        """Extract video metadata using FFmpeg"""
        try:
            probe = ffmpeg.probe(self._local_video_path)
            video_stream = next(
                (s for s in probe["streams"] if s["codec_type"] == "video"), None
            )

            if not video_stream:
                return None, None, None

            duration = float(probe["format"].get("duration", 0))
            width = int(video_stream.get("width", 0))
            height = int(video_stream.get("height", 0))
            fps = eval(video_stream.get("r_frame_rate", "0/1"))

            return duration, f"{width}x{height}", float(fps)
        except Exception as e:
            self.logger.error(f"Failed to extract metadata: {e}")
            return None, None, None

    def analyze_black_screen(
        self, timestamps: Optional[List[float]] = None
    ) -> BlackScreenInfo:
        """
        Detect black screen frames

        Args:
            timestamps: Specific timestamps to analyze (optional)

        Returns:
            BlackScreenInfo with detection results
        """
        self.logger.info("Analyzing black screen...")

        if self._local_video_path is None:
            raise RuntimeError("Video path not initialized")

        cap = cv2.VideoCapture(self._local_video_path)

        if not cap.isOpened():
            raise RuntimeError("Failed to open video file")

        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        black_frames = []
        black_timestamps = []
        frame_count = 0
        total_analyzed = 0

        # Determine frames to analyze
        if timestamps:
            # Analyze specific timestamps
            frames_to_analyze = [int(ts * fps) for ts in timestamps]
        else:
            # Analyze sampled frames
            frames_to_analyze = range(0, total_frames, self.sample_rate)

        self.logger.info(f"Sampling {len(frames_to_analyze)} frames...")

        for frame_idx in frames_to_analyze:
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
            ret, frame = cap.read()

            if not ret:
                continue

            # Calculate average brightness
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            avg_brightness = np.mean(gray.astype(float))

            total_analyzed += 1

            # Check if frame is black
            if avg_brightness < self.black_threshold:
                black_frames.append(frame_idx)
                black_timestamps.append(frame_idx / fps)

            frame_count += 1

        cap.release()

        # Calculate percentage
        black_percentage = (
            (len(black_frames) / total_analyzed * 100) if total_analyzed > 0 else 0
        )

        self.logger.info(
            f"Black frames: {len(black_frames)}/{total_analyzed} ({black_percentage:.1f}%)"
        )

        return BlackScreenInfo(
            detected=len(black_frames) > 0,
            percentage=black_percentage,
            timestamps=black_timestamps,
            threshold=self.black_threshold,
        )

    def analyze_audio(self) -> AudioInfo:
        """
        Detect audio in video

        Returns:
            AudioInfo with detection results
        """
        self.logger.info("Analyzing audio...")

        try:
            probe = ffmpeg.probe(self._local_video_path)
            audio_streams = [s for s in probe["streams"] if s["codec_type"] == "audio"]

            if not audio_streams:
                self.logger.info("No audio stream found")
                return AudioInfo(has_audio=False)

            audio_stream = audio_streams[0]
            duration = float(probe["format"].get("duration", 0))
            codec = audio_stream.get("codec_name")
            sample_rate = int(audio_stream.get("sample_rate", 0))

            self.logger.info(f"Audio found: {codec}, {sample_rate}Hz, {duration:.1f}s")

            return AudioInfo(
                has_audio=True, codec=codec, sample_rate=sample_rate, duration=duration
            )

        except ffmpeg.Error as e:
            error_msg = e.stderr.decode("utf-8") if e.stderr else str(e)
            self.logger.error(f"Audio analysis failed: {error_msg}")
            return AudioInfo(has_audio=False, error=f"FFmpeg error: {error_msg}")
        except Exception as e:
            self.logger.error(f"Audio analysis failed: {e}")
            return AudioInfo(has_audio=False, error=str(e))

    def analyze_subtitles(self) -> SubtitleInfo:
        """
        Detect subtitles in video

        Returns:
            SubtitleInfo with detection results
        """
        self.logger.info("Analyzing subtitles...")

        try:
            probe = ffmpeg.probe(self._local_video_path)
            subtitle_streams = [
                s for s in probe["streams"] if s["codec_type"] == "subtitle"
            ]

            tracks = []

            # Check embedded subtitles
            for stream in subtitle_streams:
                language = stream.get("tags", {}).get("language", "und")
                codec_name = stream.get("codec_name", "unknown")

                tracks.append(
                    SubtitleTrack(language=language, format=codec_name, embedded=True)
                )

            # Check for external subtitle files
            if self._local_video_path is None:
                raise RuntimeError("Video path not initialized")

            video_path = Path(self._local_video_path)
            video_dir = video_path.parent
            video_name = video_path.stem

            for ext in [".srt", ".ass", ".ssa", ".vtt", ".sub"]:
                sub_file = video_dir / f"{video_name}{ext}"
                if sub_file.exists():
                    # Try to detect language from filename
                    lang = self._extract_language_from_filename(sub_file.name)
                    format_type = ext[1:].upper()

                    # Avoid duplicates
                    if not any(
                        t.language == lang
                        and t.format == format_type
                        and not t.embedded
                        for t in tracks
                    ):
                        tracks.append(
                            SubtitleTrack(
                                language=lang, format=format_type, embedded=False
                            )
                        )

            self.logger.info(f"Subtitles found: {len(tracks)} tracks")

            return SubtitleInfo(has_subtitles=len(tracks) > 0, tracks=tracks)

        except ffmpeg.Error as e:
            error_msg = e.stderr.decode("utf-8") if e.stderr else str(e)
            self.logger.error(f"Subtitle analysis failed: {error_msg}")
            return SubtitleInfo(has_subtitles=False, error=f"FFmpeg error: {error_msg}")
        except Exception as e:
            self.logger.error(f"Subtitle analysis failed: {e}")
            return SubtitleInfo(has_subtitles=False, error=str(e))

    def _extract_language_from_filename(self, filename: str) -> str:
        """Extract language code from subtitle filename"""
        filename_lower = filename.lower()

        # Common language codes/patterns
        lang_patterns = {
            "en": ["en", "eng", "english"],
            "es": ["es", "spa", "spanish"],
            "fr": ["fr", "fre", "french"],
            "de": ["de", "ger", "german"],
            "it": ["it", "ita", "italian"],
            "pt": ["pt", "por", "portuguese"],
            "ru": ["ru", "rus", "russian"],
            "ja": ["ja", "jpn", "japanese"],
            "ko": ["ko", "kor", "korean"],
            "zh": ["zh", "chi", "chinese", "zho"],
            "ar": ["ar", "ara", "arabic"],
            "hi": ["hi", "hin", "hindi"],
        }

        for lang, patterns in lang_patterns.items():
            for pattern in patterns:
                if pattern in filename_lower:
                    return lang

        return "und"  # Undetermined


def main():
    """CLI entry point"""
    import argparse

    parser = argparse.ArgumentParser(
        description="Video Analyzer - Detect black frames, audio, and subtitles"
    )
    parser.add_argument("video", help="Path or URL to video file")
    parser.add_argument("--output", "-o", help="Output file path (JSON or .md)")
    parser.add_argument(
        "--black-threshold",
        type=int,
        default=10,
        help="Brightness threshold for black detection (default: 10)",
    )
    parser.add_argument(
        "--sample-rate", type=int, default=1, help="Frame sampling rate (default: 1)"
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable verbose logging"
    )

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    try:
        analyzer = VideoAnalyzer(
            video_path=args.video,
            black_threshold=args.black_threshold,
            sample_rate=args.sample_rate,
        )
        results = analyzer.analyze()

        if args.output:
            if args.output.endswith(".md"):
                results.to_report_file(args.output)
                print(f"Report saved to: {args.output}")
            else:
                results.to_file(args.output)
                print(f"Results saved to: {args.output}")
        else:
            print("\n" + results.get_report())

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    import sys

    main()
