---
name: video-analyzer
description: "Comprehensive video quality analysis including black screen detection, audio verification, and subtitle detection. Use when you need to analyze video files for quality issues such as black frames, missing audio, or absent subtitles. Supports local video files and remote URLs with automatic downloading."
license: MIT
---

# Video Analyzer

## Overview

Automated video quality detection tool that analyzes video files for common issues including black screen frames, missing audio tracks, and subtitle detection. The skill provides Python utilities for comprehensive video analysis with detailed logging and reporting.

## Prerequisites

### System Requirements

Install required Python packages:

```bash
pip install opencv-python numpy ffmpeg-python pillow
```

### FFmpeg Installation

The skill requires FFmpeg for audio and subtitle extraction:

**macOS:**
```bash
brew install ffmpeg
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get update
sudo apt-get install ffmpeg
```

**Verify installation:**
```bash
ffmpeg -version
```

## Quick Start

### Basic Video Analysis

```python
from scripts.video_analyzer import VideoAnalyzer

# Analyze a video file
analyzer = VideoAnalyzer('path/to/video.mp4')
results = analyzer.analyze()

# Print results
print(results.to_json())
```

### Analyze Remote Video URL

```python
analyzer = VideoAnalyzer('https://example.com/video.mp4')
results = analyzer.analyze()
```

## Detection Capabilities

### 1. Black Screen Detection

Detects frames that are predominantly black or dark, indicating potential video issues.

**Detection Logic:**
- Samples frames throughout the video
- Calculates average brightness per frame
- Frames with average brightness below threshold (default: 10) are flagged as black
- Reports percentage of black frames and their timestamps

**Configuration:**
```python
analyzer = VideoAnalyzer('video.mp4', black_threshold=15)  # Adjust threshold
```

### 2. Audio Detection

Verifies presence and characteristics of audio tracks.

**Detection Logic:**
- Checks for audio stream in video container
- Extracts audio statistics
- Detects silent audio sections
- Reports audio codec, sample rate, and duration

**Configuration:**
```python
analyzer = VideoAnalyzer('video.mp4', audio_threshold=0.01)  # Silence threshold
```

### 3. Subtitle Detection

Identifies presence of subtitle tracks in the video.

**Detection Logic:**
- Scans video container for subtitle streams
- Detects embedded subtitles (SRT, ASS, VTT, etc.)
- Checks for external subtitle files alongside video
- Reports subtitle languages and formats

## Common Tasks

### 1. Complete Video Quality Check

**User says:** "Check this video for black frames, audio, and subtitles"

**Implementation:**
```python
from scripts.video_analyzer import VideoAnalyzer

analyzer = VideoAnalyzer('video.mp4')
results = analyzer.analyze()

# Print detailed report
print(results.get_report())

# Check for issues
if results.has_issues():
    print(f"⚠️  Found {results.issue_count} issues:")
    if results.has_black_frames():
        print(f"  - Black frames: {results.black_frame_percentage:.1f}%")
    if not results.has_audio():
        print("  - No audio detected")
    if not results.has_subtitles():
        print("  - No subtitles detected")
else:
    print("✅ No issues detected")
```

### 2. Black Screen Specific Analysis

**User says:** "Check if this video has black screen sections"

**Implementation:**
```python
analyzer = VideoAnalyzer('video.mp4')
results = analyzer.analyze_black_screen()

if results.has_black_frames():
    print(f"Black frames detected: {results.black_frame_percentage:.1f}%")
    print(f"Black frame timestamps: {results.black_frame_timestamps}")
else:
    print("No black frames detected")
```

### 3. Audio Verification

**User says:** "Does this video have audio?"

**Implementation:**
```python
analyzer = VideoAnalyzer('video.mp4')
audio_info = analyzer.analyze_audio()

if audio_info.has_audio:
    print(f"✅ Audio found")
    print(f"  Codec: {audio_info.codec}")
    print(f"  Sample rate: {audio_info.sample_rate}Hz")
    print(f"  Duration: {audio_info.duration:.2f}s")
else:
    print("❌ No audio detected")
```

### 4. Subtitle Verification

**User says:** "Check if this video has subtitles"

**Implementation:**
```python
analyzer = VideoAnalyzer('video.mp4')
subtitle_info = analyzer.analyze_subtitles()

if subtitle_info.has_subtitles:
    print(f"✅ Subtitles found:")
    for sub in subtitle_info.tracks:
        print(f"  - {sub.language} ({sub.format})")
else:
    print("❌ No subtitles detected")
```

### 5. Batch Analysis

**User says:** "Analyze all videos in this directory"

**Implementation:**
```python
from pathlib import Path
from scripts.video_analyzer import VideoAnalyzer

video_dir = Path('videos/')
for video_path in video_dir.glob('*.mp4'):
    print(f"\nAnalyzing: {video_path.name}")
    analyzer = VideoAnalyzer(str(video_path))
    results = analyzer.analyze()
    print(results.get_report())
```

## Output Formats

### JSON Output

```python
analyzer = VideoAnalyzer('video.mp4')
results = analyzer.analyze()
print(results.to_json())
```

**JSON Structure:**
```json
{
  "video_path": "video.mp4",
  "duration": 120.5,
  "resolution": "1920x1080",
  "black_screen": {
    "detected": true,
    "percentage": 2.5,
    "timestamps": [10.2, 10.4, 10.6, 45.0, 45.2]
  },
  "audio": {
    "has_audio": true,
    "codec": "aac",
    "sample_rate": 48000,
    "duration": 120.5,
    "silent_sections": []
  },
  "subtitles": {
    "has_subtitles": true,
    "tracks": [
      {
        "language": "eng",
        "format": "srt",
        "embedded": true
      }
    ]
  },
  "has_issues": false,
  "issue_count": 0
}
```

### Markdown Report

```python
print(results.get_report())
```

**Markdown Output:**
```markdown
# Video Analysis Report: video.mp4

## Video Information
- **Duration**: 120.5s
- **Resolution**: 1920x1080
- **FPS**: 30.0

## Black Screen Detection
- **Status**: ✅ Passed
- **Black Frames**: 2.5% (3 frames)
- **Timestamps**: 10.2s, 10.4s, 10.6s

## Audio Detection
- **Status**: ✅ Passed
- **Codec**: AAC
- **Sample Rate**: 48000 Hz
- **Duration**: 120.5s

## Subtitle Detection
- **Status**: ✅ Passed
- **Tracks**: 1 found
  - English (SRT, embedded)

## Overall Status
✅ No issues detected
```

### Detailed Log Output

For debugging and detailed analysis:

```python
import logging
logging.basicConfig(level=logging.DEBUG)

analyzer = VideoAnalyzer('video.mp4')
results = analyzer.analyze()
```

## Configuration Options

### VideoAnalyzer Parameters

```python
VideoAnalyzer(
    video_path,              # Path or URL to video file
    black_threshold=10,      # Brightness threshold for black detection (0-255)
    audio_threshold=0.01,    # Volume threshold for silence detection
    sample_rate=1,           # Frame sampling rate (every Nth frame)
    download_dir='./downloads',  # Directory for downloaded videos
    timeout=300              # Download timeout in seconds
)
```

### Custom Thresholds

**Black Screen Threshold:**
- Lower values (5-10): Stricter detection (only very dark frames)
- Higher values (15-20): More lenient (dark gray also considered black)

**Audio Threshold:**
- Lower values (0.001-0.01): Detect very quiet audio as silent
- Higher values (0.05-0.1): Only detect complete silence

## Error Handling

### Common Issues

**Video file not found:**
```python
try:
    analyzer = VideoAnalyzer('nonexistent.mp4')
    results = analyzer.analyze()
except FileNotFoundError as e:
    print(f"Error: {e}")
```

**Invalid video format:**
```python
try:
    analyzer = VideoAnalyzer('corrupted.mp4')
    results = analyzer.analyze()
except VideoFormatError as e:
    print(f"Video format error: {e}")
```

**FFmpeg not found:**
```python
analyzer = VideoAnalyzer('video.mp4')
if not analyzer.ffmpeg_available():
    print("Error: FFmpeg is not installed")
    print("Please install FFmpeg: brew install ffmpeg (macOS)")
```

### Graceful Degradation

The analyzer continues even if some checks fail:

```python
results = analyzer.analyze()
if results.audio_error:
    print(f"Audio check failed: {results.audio_error}")
    # Other checks still available
    print(f"Black screen check: {results.black_screen}")
```

## Advanced Usage

### Custom Frame Sampling

```python
# Sample every 10th frame for faster analysis
analyzer = VideoAnalyzer('video.mp4', sample_rate=10)

# Sample specific timestamps
analyzer = VideoAnalyzer('video.mp4')
results = analyzer.analyze(timestamps=[0, 30, 60, 90])
```

### Export Results to File

```python
analyzer = VideoAnalyzer('video.mp4')
results = analyzer.analyze()

# Export JSON
results.to_json('analysis_results.json')

# Export Markdown report
results.to_report('analysis_report.md')
```

### Integration with Logging Systems

```python
import logging
from scripts.video_analyzer import VideoAnalyzer

logger = logging.getLogger(__name__)

analyzer = VideoAnalyzer('video.mp4')
results = analyzer.analyze()

if results.has_issues():
    logger.warning(f"Video quality issues detected: {results.issue_count}")
    for issue in results.get_issues():
        logger.error(f"Issue: {issue}")
```

## Resources

### scripts/video_analyzer.py
- Main video analyzer implementation
- Black screen detection using OpenCV
- Audio analysis using FFmpeg
- Subtitle stream detection
- Multiple output format support
- Remote video download capability

### references/
- FFmpeg documentation
- Video format specifications
- Subtitle format references

## Performance Considerations

**Processing Speed:**
- Black screen detection: ~0.1s per frame sampled
- Audio extraction: Depends on video length (~1s per minute)
- Subtitle detection: Nearly instant (metadata only)

**Memory Usage:**
- Frames are processed sequentially (not loaded all at once)
- Memory efficient for large videos
- Adjustable sampling rate for performance tuning

**Large Videos:**
- Use `sample_rate` parameter to reduce processing time
- Consider analyzing video segments separately for very long videos
- Download remote videos with timeout protection

## Limitations

1. **OCR Subtitle Detection**: Currently only detects embedded subtitle tracks. Burned-in subtitles (text rendered directly into video frames) require OCR integration.

2. **Audio Content Analysis**: Detects presence of audio but cannot verify audio quality or content accuracy.

3. **Color Grading**: Black screen detection based on brightness may flag intentionally dark scenes (night scenes, fade to black).

4. **Network Videos**: Remote video analysis requires stable internet connection and depends on server accessibility.

## Best Practices

1. **Always check FFmpeg availability** before analysis
2. **Use appropriate thresholds** based on your video content
3. **Review black frame timestamps** before flagging issues (may be intentional fades)
4. **Save analysis results** for audit trails
5. **Handle exceptions gracefully** in production code
6. **Test with known good videos** to establish baseline thresholds
