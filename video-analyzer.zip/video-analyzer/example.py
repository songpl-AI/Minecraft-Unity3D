#!/usr/bin/env python3
"""
Example usage of the Video Analyzer skill
"""

from scripts.video_analyzer import VideoAnalyzer


def example_basic_analysis():
    """Basic video analysis example"""
    print("=== Basic Video Analysis ===\n")

    # Analyze a local video file
    analyzer = VideoAnalyzer("example_video.mp4")
    results = analyzer.analyze()

    # Print detailed report
    print(results.get_report())
    print()

    # Check for issues
    if results.has_issues():
        print(f"⚠️  Found {results.issue_count} issue(s):")
        for issue in results.get_issues():
            print(f"  - {issue}")
    else:
        print("✅ No issues detected")


def example_black_screen_detection():
    """Black screen specific analysis example"""
    print("\n=== Black Screen Detection ===\n")

    analyzer = VideoAnalyzer("example_video.mp4", black_threshold=15)
    results = analyzer.analyze_black_screen()

    if results.detected:
        print(f"Black frames detected: {results.percentage:.1f}%")
        print(f"Timestamps: {results.timestamps}")
    else:
        print("No black frames detected")


def example_audio_verification():
    """Audio verification example"""
    print("\n=== Audio Verification ===\n")

    analyzer = VideoAnalyzer("example_video.mp4")
    audio_info = analyzer.analyze_audio()

    if audio_info.has_audio:
        print(f"✅ Audio found")
        print(f"  Codec: {audio_info.codec}")
        print(f"  Sample rate: {audio_info.sample_rate}Hz")
        print(f"  Duration: {audio_info.duration:.2f}s")
    else:
        print("❌ No audio detected")
        if audio_info.error:
            print(f"Error: {audio_info.error}")


def example_subtitle_verification():
    """Subtitle verification example"""
    print("\n=== Subtitle Verification ===\n")

    analyzer = VideoAnalyzer("example_video.mp4")
    subtitle_info = analyzer.analyze_subtitles()

    if subtitle_info.has_subtitles:
        print(f"✅ Subtitles found:")
        for track in subtitle_info.tracks:
            embed_str = "(embedded)" if track.embedded else "(external)"
            print(f"  - {track.language} ({track.format}, {embed_str})")
    else:
        print("❌ No subtitles detected")


def example_remote_video_analysis():
    """Remote video analysis example"""
    print("\n=== Remote Video Analysis ===\n")

    url = "https://example.com/video.mp4"
    analyzer = VideoAnalyzer(url)
    results = analyzer.analyze()

    print(results.get_report())


def example_json_output():
    """JSON output example"""
    print("\n=== JSON Output ===\n")

    analyzer = VideoAnalyzer("example_video.mp4")
    results = analyzer.analyze()

    # Export to JSON string
    json_str = results.to_json()
    print(json_str)

    # Or save to file
    results.to_file("analysis_results.json")
    print("\nResults saved to: analysis_results.json")


def example_markdown_report():
    """Markdown report export example"""
    print("\n=== Markdown Report Export ===\n")

    analyzer = VideoAnalyzer("example_video.mp4")
    results = analyzer.analyze()

    # Save report to markdown file
    results.to_report_file("analysis_report.md")
    print("Report saved to: analysis_report.md")


def example_custom_thresholds():
    """Custom thresholds example"""
    print("\n=== Custom Thresholds ===\n")

    # Higher black threshold (more lenient)
    analyzer = VideoAnalyzer(
        "example_video.mp4",
        black_threshold=20,  # Detect darker gray as black
        sample_rate=5,  # Sample every 5th frame for faster analysis
    )
    results = analyzer.analyze()

    print(f"Black frame percentage: {results.black_frame_percentage:.1f}%")
    print(f"Black frame timestamps: {results.black_frame_timestamps}")


def example_batch_analysis():
    """Batch analysis example"""
    print("\n=== Batch Analysis ===\n")

    from pathlib import Path

    video_dir = Path("videos/")
    if video_dir.exists():
        for video_path in video_dir.glob("*.mp4"):
            print(f"\nAnalyzing: {video_path.name}")
            analyzer = VideoAnalyzer(str(video_path))
            results = analyzer.analyze()

            if results.has_issues():
                print(f"  Issues: {results.issue_count}")
            else:
                print("  ✅ No issues")
    else:
        print("Videos directory not found")


def example_timestamp_analysis():
    """Analyze specific timestamps example"""
    print("\n=== Specific Timestamp Analysis ===\n")

    analyzer = VideoAnalyzer("example_video.mp4")

    # Analyze only specific timestamps (in seconds)
    timestamps = [0.0, 30.0, 60.0, 90.0, 120.0]  # Check at 0s, 30s, 60s, 90s, 120s
    results = analyzer.analyze(timestamps=timestamps)

    if results.black_screen and results.black_screen.detected:
        print(f"Black frames at: {results.black_screen.timestamps}")


def main():
    """Run all examples"""
    print("Video Analyzer - Example Usage\n")
    print("=" * 50)
    print()

    try:
        example_basic_analysis()
        example_black_screen_detection()
        example_audio_verification()
        example_subtitle_verification()
        example_json_output()
        example_markdown_report()
        example_custom_thresholds()

    except FileNotFoundError as e:
        print(f"\n❌ Error: {e}")
        print("\nPlease provide a valid video file path to run these examples.")
        print("\nExample usage:")
        print("  python example.py")
        print("\nMake sure 'example_video.mp4' exists in the current directory.")

    except Exception as e:
        print(f"\n❌ Error: {e}")


if __name__ == "__main__":
    main()
